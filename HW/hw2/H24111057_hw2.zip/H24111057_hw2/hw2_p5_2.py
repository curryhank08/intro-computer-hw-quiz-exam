""" 
author: H24111057 姚博瀚
"""

def longestPalindrome(s):
    if len(s) <= 1:
        return s
    
    Max_Len=1
    Max_Str=s[0]
    for i in range(len(s)-1):
        for j in range(i+1,len(s)):
            if j-i+1 > Max_Len and s[i:j+1] == s[i:j+1][::-1]:
                Max_Len = j-i+1
                Max_Str = s[i:j+1]

    return Max_Str, Max_Len

input_string = str(input("Enter a string: "))
result = longestPalindrome(input_string)
print(F"Longest palindrome substring is: {result[0]}")
print(f"Length is: {result[1]}")
